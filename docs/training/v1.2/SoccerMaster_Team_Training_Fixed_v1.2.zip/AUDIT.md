# Reference implementation review

Historical review notes below. Current v1.2 disposition and test evidence are in FIXES_v1.2.md and TEST_RESULTS_v1.2.txt. The nine subsequent red-team findings have reference-code corrections or explicit integration controls; live-game gates are not claimed closed. Current test count: 36.

v1.1 expansion: six additional curriculum tests pass, bringing the total to 22. The full schedule contains 108 distinct authored situation strings and all 36 weeks have A/B/C slots. All nine career roles map to an eligible base family; complementary role starts remain host integration work. Calendar position never grants earned difficulty. Separate scenario capability checks prevent base-game availability being misrepresented as implemented curriculum coverage. Cross-season reward collisions are addressed by the documented requirement to pass season-qualified schedule IDs to the original run API; actual persisted entitlement migration remains NOT RUN.

Scope: this package's pure JavaScript coordinator and content, reviewed before delivery. Not a penetration test of the game or an external certification.

## Corrected during implementation

- Tick deduplication initially risked an ever-growing per-frame event ledger. Ticks now use a monotonic counter and do not fill the durable event-ID set. Same/stale tick cannot advance time again.
- Evidence originally deduplicated all dimensions together. Keys now include actor, opportunity and dimension, so decision and execution can be separately observed without reward farming via new event IDs.
- Actor IDs resembling prototype properties could collide with normal objects. Aggregation now uses null-prototype dictionaries and own-entry conversion; regression coverage includes `__proto__`.
- Roster assignment now rejects keeper flags inconsistent with the declared role. It never substitutes a keeper as an outfield player or silently drops the human.
- No capability list means no selectable runtime practices. Content existence is never treated as proof of a working live drill.
- Completion remains a request with an entitlement tuple, never a new attribute award. Duplicate/atomic persistence requires the existing host service and is not claimed implemented here.

## Verification

16 behavioral tests pass, including 24-card integrity, every listed role/level selection, exact participant counts, human/keeper preservation, duplicate evidence, minimum evidence gating, adaptive load precedence, duplicate tick, pause/stale generation, full three-round completion and aborted/stale-context completion rejection. Node execution output is included as TEST_RESULTS.txt.

Catalog cards and JSON are generated from the same source, avoiding independent edits. File checksums and a local Git history are packaged for reproducibility. There was no original game source in this workspace; this is an additive standalone repository.

## Unresolved integration gates — not hidden as passes

Actual field/target geometry and score predicates; player AI and perception; all 24 playable scenes; asymmetric-role rotation variants; deterministic world resume; genuine evidence extraction; rules/controls compatibility; persisted cross-tab completion; storage failure recovery; skill transfer to 9v9; performance on a phone; physical iPhone tests. All are NOT RUN here.

The reducer assumes trusted, version-validated saved state from the host, not arbitrary network input. The host must bind actors/evidence to its run roster and prevent forged telemetry. Client-local save editing is not prevented. Thresholds and dimensions are provisional game design values. There is no medical workload model, no automated behavioral diagnosis and no claim that a synthetic score measures a child's intelligence.

import {writeFileSync} from 'node:fs';
import {sessions,validateCurriculum,scenarioDefinition} from './seasons.mjs';
import {families,catalog} from './catalog.mjs';
const counts=validateCurriculum();
writeFileSync(new URL('season-sessions.json',import.meta.url),JSON.stringify({version:'1.2',curriculumVersion:2,counts,sessions},null,2)+'\n');
const layouts=sessions.flatMap(s=>Object.keys(s.roleRoutes).flatMap(role=>Array.from({length:s.maxLevel},(_,i)=>scenarioDefinition(s.id,role,i+1,'reference'))));
writeFileSync(new URL('scenario-layouts.json',import.meta.url),JSON.stringify({status:'reference-layouts-not-live-approved',count:layouts.length,rulesProfile:'reference',definitions:layouts},null,2)+'\n');
let out='# SoccerMaster — two-season team-training program\n\n18 weeks per season × three sessions per week = 108 scheduled sessions. Each entry is an authored scenario using a supported small-sided game. These are 108 session plans built on 24 base practice cards, not 108 verified live-game implementations. Role routes are mappings, not claims of 972 independently authored drills.\n\n';
for(let season=1;season<=2;season++) {
 out+=`## Season ${season}\n\n`;
 out+='| Week | Team theme | Session A | Session B | Session C |\n|---|---|---|---|---|\n';
 for(let week=1;week<=18;week++) {
  const w=sessions.filter(s=>s.season===season&&s.week===week);
  out+=`| ${week} | ${w[0].theme} | ${families[w[0].focus].name} | ${families[w[1].focus].name} | ${families[w[2].focus].name} |\n`;
 }
 out+='\n';
 for(const s of sessions.filter(s=>s.season===season)) {
  const cards=catalog.filter(d=>d.family===s.focus&&d.level<=s.maxLevel);
  out+=`### ${s.id} — ${s.theme}: ${families[s.focus].name}\n\n`+
   `**Football situation:** ${s.scenario}.\n\n`+
   `**Game choice:** ${cards.map(d=>`${d.id} (${d.name}, ${d.participants.total} players)`).join('; ')}. Select only the player's earned level up to this session's cap of ${s.maxLevel}; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.\n\n`+
   `**Coach question:** ${s.coachQuestion}\n\n**Learning evidence:** ${s.objective}.\n\n`+
   `**9v9 transfer context:** ${families[s.focus].behaviors.join('; ')}. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.\n\n`+
   `**Match transfer:** ${s.transferQuestion}\n\n`+
   `**Role routes:** ${Object.entries(s.roleRoutes).map(([role,r])=>`${role} → ${r.family}${r.relationship==='primary'?'':' (complementary)'}`).join('; ')}. Complementary sessions must be labeled and adapted to this week's team problem by the host author.\n\n`+
   `**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.\n\n`;
  out+='| Career role | Resolved practice question | Evidence objective |\n|---|---|---|\n';
  for(const role of Object.keys(s.roleRoutes)) {const r=scenarioDefinition(s.id,role,1,'reference');out+=`| ${role} | ${r.coachQuestion} | ${r.objective} |\n`;}
  out+='\n';
 }
}
writeFileSync(new URL('TWO_SEASON_PROGRAM.md',import.meta.url),out);

# Eight-week spiral curriculum — proposed content schedule

Historical v1.0 sketch. Superseded by TWO_SEASON_PROGRAM.md: two eighteen-week seasons, 108 scheduled sessions. Retained for provenance, not the active schedule.

Three available team-training slots per week are shown as a design option. Bind these to the existing story schedule; do not invent extra mandatory sessions or reward slots. Weeks are curriculum blocks, not a replacement for Season One chronology. A missed or unavailable slot does not erase later story progress. Repeat a problem with a different legal start before raising level.

| Block | Slot A: main problem | Slot B: linked problem | Slot C: application / observation |
|---|---|---|---|
| 1 | B1: escape pressure | D1: pressure and cover | B1 mirrored; observe GK/back/6 outlets in next 9v9 |
| 2 | S1: recognize two targets | C1: support the next pass | S1 with varied defenders; observe whether players switch only when useful |
| 3 | W1: draw a defender wide | F1: pass or shoot | Wide interaction with realistic reset; observe far-side movement |
| 4 | T1: respond to possession change | D2 if ready, otherwise D1 | Transition with no extra scoring incentive; observe central recovery |
| 5 | B2 if ready, otherwise B1 | K1: keeper/back-line connection | Build against a different press; observe patient reset versus penetration |
| 6 | C2 if ready, otherwise C1 | S2 if ready, otherwise S1 | Remove neutral assistance in a separately supported equal-number card |
| 7 | W2 or W1 | F2 or F1 | Attacking-unit choices; observe protection against the counter |
| 8 | T2 or T1 | Role-specific revisit of weakest supported family | Unrestricted 9v9 transfer and later retention check |

Level 3 is available after repeated successful evidence, not automatically at week eight. GK careers use supported build, transition, finishing and keeper cards; never route a goalkeeper to a winger-only slot. If the story locks an unsupported focus, make that coverage gap visible and resolve it in content authoring. Home juggling and schoolyard play keep their own schedules and evidence namespaces.

## Example coached session: draw pressure, then choose

Career role: right winger. Focus: switch. Starting card: S1, six players, 25 × 25 m, two mini-goals at each end, final 5 m scoring zones. No goalkeepers. Other squad members rotate or play another supported group; six active actors remain six.

First bout: play freely within the target rules. Coach asks, “Which goal became easier when the defender moved?” The engine records both the winger's carrying choices and the teammate's support opportunities. It does not require a switch every attack.

Second bout: use the same rules with a mirrored legal starting situation. Opponents defend normally. The player can attack the open same-side lane, draw pressure and pass across, or reset if both targets are blocked. A teammate should not run behind the defender merely because a cone marks that position.

Third bout: no optional bonus/instruction overlay. Look for the same useful choices independently. A lucky long shot from outside the marked scoring zone cannot count as a legal goal. The training score records goals; learning feedback records the observable opportunities separately.

Transfer: in the next normal 9v9 match, assess whether the winger retains width when needed and narrows after a real handover. Do not claim that passing the small-sided exercise proves this larger positional interaction. Ask again in a later match before calling the behavior retained.

## Difficulty design

More space can provide perception time but also lengthens passing and recovery distances. Extra teammates can provide an outlet but alter the problem. Fewer touches can accelerate play but remove a useful dribble. Change only the variable relevant to the observed problem. Keep the easy version opposed and decision-rich. Preserve failure, recovery, and another reasonable solution.

The game-time bouts are entertainment pacing. For an actual on-field session, the coach must set suitable duration, rest, pitch and rules for their group; the phone game's pacing is not an exercise prescription.

# Build the SoccerMaster team-training layer

v1.2 precedence: read FIXES_v1.2.md before implementing this historical base contract. Its bound scheduled-run API, exact roster/layout checks, bounded evidence ingestion, participation policy and task-specific adaptation supersede conflicting statements below. Current tests: 36, including regression cases.

21 October 2026 · Reference implementation v1.0

## What this delivery actually contains

- 24 original small-sided practice definitions across eight families and three levels.
- Executable dependency-free JavaScript for selection, exact participant assignment, round lifecycle, evidence aggregation and adaptation recommendations.
- A research synthesis with twelve inspected primary sources.
- Coach/AI interaction and telemetry contracts below.
- Behavioral tests; no claim of live game integration, graphics, ball physics, save concurrency or iPhone verification.

Start with the current SoccerMaster-Retro repository and branch. Inspect its existing team-training scene, gameplay AI, input schema, rules, career identity, weekly entitlement, progression and persistence services. Preserve current working systems. This module is a reference service to adapt, not a second gameplay loop. Do not overwrite the current implementation with the older nine-player decision prototype: it rejects small-sided rosters and lacks this training lifecycle.

The earlier Training/Schoolyard audit was read for its persistence and coverage requirements. The current revision ZIP/game source was not materialized or inspected in this turn. Therefore this delivery is additive and does not claim to supersede all current package contents. Leave home skills, required juggling, schoolyard games, story scenes and their existing rewards separate.

## Player experience

The weekly team-training card shows the locked focus, a short coach question and the player’s actual role. Load the existing training venue with clear boundaries and useful player scale. Briefly introduce the scoring targets. Keep play continuous; avoid pausing on every touch. At round end show one observed strength, one useful cue, and the next football challenge. If evidence is insufficient, say so and change the starting situation to provide an opportunity.

Suggested phone pacing is three 90-second bouts, with short optional reflections. These are game-time tuning values, not real training prescriptions. Round one explores the problem; round two applies the selected task; round three should remove any optional incentives. Free play still obeys the legitimate target and boundary rules. A later normal 9v9 match supplies separate transfer evidence. This reference reducer implements the three bouts; the opening free-play presentation and later match transfer capture are host tasks.

Use the CURRENT approved controls. Do not revive obsolete four-button restrictions or the removed BLOCK button from historical excerpts. Chip/aerial play, shoulder challenge and goalkeeper throw/punt requests are allowed only if the current approved executor implements them. Every practice must be playable with its enabled capabilities; unavailable actions cannot become mandatory scoring conditions. Preserve career control lock. NPCs share physics and attribute limits with the player.

## Session composition and selection

`selectPractice` takes the locked family, career role, level, available roster and implemented drill-ID capability list. Empty capabilities deliberately mean unavailable. Enable an ID only when its targets, restart rules, AI and evidence adapter work in the actual scene. The function does not silently change the focus or increase level. `recent` can support variant ordering when more cards are added; v1 has exactly one card per family/level, so variety currently comes from host-authored legal starts, opponents and side mirroring.

Participants counts are explicit: outfield A/B, neutrals and GK A/B. A label like 4v4 + two keepers means ten total, never eight. No phantom participants, invisible GK, dummy opponents or nine-player padding. If a roster cannot support the chosen practice, display unavailable or provide a separately authored valid variant. Teams in training can mix club players, but never fabricate additional career characters. With eighteen available players and six active, run parallel NPC groups or a visible rotation; the reference module returns the bench and does not simulate those other fields.

`assignParticipants` keeps the controlled character present, keeps designated keepers in keeper slots, rotates the other actors, and alternates teams on symmetric cards. Asymmetric cards need a host-authored swapped setup to teach both directions; the module does not falsely flip a main goal into mini-goals. Rotate NPC responsibility and opponents between rounds; retain the human’s career identity and eligible function. Keeper/outfield eligibility comes from the roster, not arbitrary shirt numbers.

## Live scenario rules

Practice adapter reads each card's objective, pitch, counts and turnover text, then implements explicit physical target geometry. Mini-goals sit symmetrically on the end lines; two exit gates must be separated so either can be defended and neither is hidden behind UI. A designated scoring-zone card requires a legal shot origin within the zone; an end-zone point requires actual controlled reception or a legal controlled carry, as specified by the authored variant. All dimensions are metres in simulation coordinates, not screen pixels. Goal sizes, penalty areas, restart distances and offside profile come from the inspected game rules; these cards do not invent universal youth laws.

Goal/out restart belongs to the conceding/non-touching team per the authored training profile. Keep a live counterattack after a regain. A contested ball does not switch a neutral player’s allegiance until secure possession is established. Physical keeper possession, deflections and rebounds remain real. Use one ball unless an explicitly implemented variant requires otherwise. No double-scoring an end-zone dwell; require leaving and a new valid attack episode before another point. Reset after a valid point. Dead-ball restarts do not accumulate tactical evidence.

## NPC coordination required in the host

The catalog supplies coaching behaviors; these are NOT an implemented replacement for the host player AI. Adapt existing NPC decisions to the actual participants and targets:

| State | Carrier / nearest player | Teammates | Opposition / goalkeeper |
|---|---|---|---|
| Secure attack | Read carry, pass, shot and reset from delivered perception | Support angle, depth and width; avoid duplicate runs | First defender pressures when feasible; cover blocks dangerous route |
| Switch opportunity | Engage pressure before releasing if that remains safe | Far outlet remains available; next runner times movement | Defenders shift without teleporting; far cover protects second target |
| Wide penetration | Compare carry, cutback and reset | Separate near/deep finishing lanes; retain rest defense | Outside defender delays; central defender protects goal; GK adjusts angle |
| Possession lost | Nearest effective defender assesses supported pressure | Protect middle and recover goal-side | New carrier chooses counter or secure pass |
| Loose ball | Use observed arrival and contact feasibility | Provide support/cover; avoid all-player chase | GK sweeps only when feasible and legally permitted |
| Friendly pass in flight | No new kick without control | Receiver updates to observed trajectory; others support | Interception and first touch remain physical |
| Dead ball / reflection | Stop accepting match actions | Cancel pending intentions and input charge | Reset through the existing scene lifecycle |

Do not force a far winger inside while nobody supplies width. Do not require an 8 to follow an opposing 6 into irrelevant space. In small formats, one actor can fulfill different temporary tasks, but cannot simultaneously be the distant cover and the near receiver. Opponents adapt through observed positioning and ability, not access to unreleased joystick input or future outcomes.

## Evidence contract and feedback

Emit opportunity records from trustworthy simulation observations, not client button counts. Each record has an immutable `id`, `actorId`, `opportunityId`, `dimension`, `quality` in [0,1], `observable`, and `eligible`. Supported dimensions: decision, support, defense, execution. The evaluator aggregates these records; the host must implement the actual detectors. It does not infer football quality from raw positions by itself.

Use one record per actor/opportunity/dimension. First valid record wins; corrections require an explicit versioned evaluation policy, not a second award. Decision opportunities begin when the actor has control and meaningful feasible alternatives. Off-ball windows begin when that actor can actually help; repeated render frames are not new opportunities. Stop the window on commitment, loss, expiry or rule event. Retain the pre-action observation/available options and evaluator version with the full host trace. Use bounded, documented utility with a tolerance band for similarly good choices; do not label it calibrated xG.

| Family | Detect an eligible opportunity | Evaluate the decision / interaction | Common false positive to reject |
|---|---|---|---|
| Build | Secure control; pressure; physically reachable outlet/reset | Pass/carry/clear option keeps or gains useful access given own-goal risk | Rewarding every short pass, even into a trap |
| Switch | Same-side pressure and a genuinely reachable alternative | Choice exploits better space; same-side continuation can also be good | Awarding repeated harmless lateral passes |
| Combine | A teammate can receive and another can change a defender's problem | Timely support or third-player run opens a lane while staying legal | Running to a premarked cone regardless of defender |
| Wide | Ball reaches flank; overlapping/support routes actually exist | Complementary runs, usable cutback, cover retained | Two attackers occupying the same channel |
| Defend | Actor can influence ball or dangerous lane | Pressure with cover, delay when outnumbered, protect central threat | Counting tackles or opponent misses as proof of good defense |
| Transition | Verified possession change; actor has a viable response | Supported counterpress or recovery appropriate to threat | Scoring any movement toward the ball as successful pressing |
| Finish | Feasible shot or pass choices in scoring range | Compare observed angle, pressure, blocking and teammate access | Goal equals good decision; miss equals bad decision |
| Keeper | Reachable ball/attacker or distribution options | Set/sweep/retain/distribute appropriate to arrival and rules | Automatic rush or a save caused solely by a weak shot |

Unknown evidence is excluded. The code reports null until at least five valid opportunities in a dimension. Report sample size alongside score. Never compare a neutral’s passing percentage directly with a pressured defender’s. Separate learning evidence from team score and normal-match statistics. Feedback must cite an actual trace: “You held cover when your teammate stepped,” not an invented event.

## Adaptation and progression

`recommendNext` returns advice, not authority to change the scheduled focus or persistent attributes. Provisional defaults: under 0.4 after enough evidence → slightly more width; at least 0.75 after two successful sessions → consider next level; high host load signal → shorten bouts before increasing difficulty. These values require playtesting and are not research-established cutoffs. Apply one change only between bouts/sessions. Physical fatigue continues through the existing energy model; neither restart nor Retry refills it without an existing explicit rule.

Persistent growth uses the existing progression service and its player/NPC rates, caps, decline rules and entitlements. `attributeDelta:null` means this module creates no new progression economy. Returning an entitlement tuple is a proposed completion payload, not a reward grant. Practice-run IDs must never substitute for the host weekly reward key. Training evidence is namespaced separately from match evidence and school/home activities.

## Persistence and isolation

`createRun` binds career/week/slot, content version, practice, seed and human identity. `reduceRun` is pure and supports ready → playing → reflection → next round → complete; pause/resume and abort are explicit. Tick IDs are monotonic; duplicate/stale ticks do not add time. Generation changes reject prior-round callbacks. The host owns fixed-step timing, state validation at load, deterministic world snapshot/seed restoration, and cancellation of stale physics/input commands.

Persist irreversible boundaries using the existing save transaction: run start, committed action/seed as required by the game, round outcome and final completion. This module does not provide a storage backend, authoritative network validation or two-tab atomicity. Finalize through the existing atomic compare-and-set entitlement service, including allowed progression effects and a replay-safe outcome delivery. A retry may change practice-run ID, never the weekly entitlement. Reject completion against a different current career/week/slot; recover original pending work explicitly. A storage failure cannot be displayed as saved success.

Snapshot/restore scene configuration on exit: roster, pitch bounds, goals, rules, camera, neutral allegiance, actor ownership, timers and AI queues. Abort does not award completion. Restoring a different content version requires a migration/recovery decision; never silently resimulate old committed actions under new rules.

## Build and release gates

1. Run `node --test engine.test.mjs` in this folder. Adapt to the project's test setup if needed; no installation required.
2. Implement and verify each drill ID before adding it to capabilities. Return a 24-row actual coverage report: enabled/deferred, supported roles, geometry/restarts, AI, detectors, tests.
3. Exercise all supported role/focus combinations, missing keeper/roster cases, both attacking directions, clear and contested turnovers, pass flight, rebound and offside-profile cases.
4. Test lifecycle interruptions and failure boundaries: duplicate tick, double Continue, stale round callback, pause while charging, app backgrounding, crash before/after completion, simultaneous tabs, retry seed and career/week change.
5. Test scene exit into a normal match; no training configuration or score leaks. Verify current controls, keeper identity and no human AI overrides.
6. Compare 30/60/120 Hz rendering against the same simulation trace. Measure responsiveness on target phone; browser emulation is not a real iPhone test.
7. Report exact tested commit, PASS/FAIL/NOT RUN, visible evidence and remaining issues. Do not deploy unrelated changes or claim certification from these reference tests.

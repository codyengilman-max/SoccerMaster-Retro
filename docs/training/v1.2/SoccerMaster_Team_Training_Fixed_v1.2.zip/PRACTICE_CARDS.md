# SoccerMaster — 24 small-sided practice cards

Original reference designs; provisional geometry and game-time dose. See DEVIN_HANDOFF.md for shared rules, telemetry and adapter requirements. All cards are reference prototypes until live implementation is verified. Sources refer to RESEARCH.md.

## B1 · Find the exit

- Family / level: Play out under pressure / 1
- Players: 3 outfield + 1 GK versus 2 outfield + 0 GK; 0 neutrals; **6 total**.
- Pitch: 30 × 24 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6, 8.
- Objective: A scores by controlled reception beyond either exit gate; B scores in the main goal.
- On turnover: B attacks goal immediately; A recovers.
- Coach question: Can we play through, around, or safely reset?
- Player interactions: GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover.
- Evidence: Recognize a reachable outlet without exposing an immediate central turnover.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R11; our adaptation, not an endorsed source drill.

## B2 · Break the first press

- Family / level: Play out under pressure / 2
- Players: 4 outfield + 1 GK versus 3 outfield + 0 GK; 0 neutrals; **8 total**.
- Pitch: 38 × 28 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6, 8.
- Objective: A progresses through either end gate; B attacks the main goal.
- On turnover: Play continues on regain; reset only after goal or ball out.
- Coach question: Can we play through, around, or safely reset?
- Player interactions: GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover.
- Evidence: Recognize a reachable outlet without exposing an immediate central turnover.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R11; our adaptation, not an endorsed source drill.

## B3 · Two-way build

- Family / level: Play out under pressure / 3
- Players: 4 outfield + 1 GK versus 4 outfield + 1 GK; 0 neutrals; **10 total**.
- Pitch: 44 × 32 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6, 8.
- Objective: Score in opposing goal; begin alternate rounds at each GK.
- On turnover: Immediate two-way transition.
- Coach question: Can we play through, around, or safely reset?
- Player interactions: GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover.
- Evidence: Recognize a reachable outlet without exposing an immediate central turnover.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R11; our adaptation, not an endorsed source drill.

## S1 · Two goals to choose

- Family / level: Draw pressure and switch / 1
- Players: 3 outfield + 0 GK versus 3 outfield + 0 GK; 0 neutrals; **6 total**.
- Pitch: 25 × 25 m (editable starting design).
- Eligible career roles: 6, 8, LW, RW, LB, RB.
- Objective: Attack two mini-goals; finish inside final 5 m zone.
- On turnover: New team can attack either opposite target.
- Coach question: Has the defender moved enough to open the other side?
- Player interactions: Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle.
- Evidence: Switch when far-side access improves; continue forward when the same-side route remains better.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R05, R10; our adaptation, not an endorsed source drill.

## S2 · Connect the opposite side

- Family / level: Draw pressure and switch / 2
- Players: 4 outfield + 0 GK versus 4 outfield + 0 GK; 1 neutrals; **9 total**.
- Pitch: 32 × 36 m (editable starting design).
- Eligible career roles: 6, 8, LW, RW, LB, RB.
- Objective: Two mini-goals per end; neutral supports possession.
- On turnover: Neutral changes allegiance only after secure possession.
- Coach question: Has the defender moved enough to open the other side?
- Player interactions: Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle.
- Evidence: Switch when far-side access improves; continue forward when the same-side route remains better.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R05, R10; our adaptation, not an endorsed source drill.

## S3 · Switch then exploit

- Family / level: Draw pressure and switch / 3
- Players: 5 outfield + 1 GK versus 5 outfield + 1 GK; 0 neutrals; **12 total**.
- Pitch: 48 × 38 m (editable starting design).
- Eligible career roles: 6, 8, LW, RW, LB, RB.
- Objective: Normal goals; display feedback for useful switches, never require one.
- On turnover: Normal two-way transition.
- Coach question: Has the defender moved enough to open the other side?
- Player interactions: Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle.
- Evidence: Switch when far-side access improves; continue forward when the same-side route remains better.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R05, R10; our adaptation, not an endorsed source drill.

## C1 · Give and go or turn

- Family / level: Receive, support and combine / 1
- Players: 2 outfield + 0 GK versus 2 outfield + 0 GK; 1 neutrals; **5 total**.
- Pitch: 24 × 18 m (editable starting design).
- Eligible career roles: 6, 8, 9, LW, RW.
- Objective: Controlled reception in opposite 3 m end zone.
- On turnover: Reverse attack direction for new possessor.
- Coach question: Can you help the receiver before the ball arrives?
- Player interactions: Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues.
- Evidence: Offer a reachable passing angle or exploit a third-player opening without running offside.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R03, R08; our adaptation, not an endorsed source drill.

## C2 · Third player choice

- Family / level: Receive, support and combine / 2
- Players: 3 outfield + 0 GK versus 3 outfield + 0 GK; 1 neutrals; **7 total**.
- Pitch: 30 × 24 m (editable starting design).
- Eligible career roles: 6, 8, 9, LW, RW.
- Objective: Score in opposing two mini-goals.
- On turnover: Neutral supports new team after possession is secure.
- Coach question: Can you help the receiver before the ball arrives?
- Player interactions: Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues.
- Evidence: Offer a reachable passing angle or exploit a third-player opening without running offside.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R03, R08; our adaptation, not an endorsed source drill.

## C3 · Find the pocket

- Family / level: Receive, support and combine / 3
- Players: 4 outfield + 1 GK versus 4 outfield + 1 GK; 0 neutrals; **10 total**.
- Pitch: 40 × 30 m (editable starting design).
- Eligible career roles: 6, 8, 9, LW, RW.
- Objective: Normal goals with free movement between thirds.
- On turnover: Receiver and runner must recover on loss.
- Coach question: Can you help the receiver before the ball arrives?
- Player interactions: Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues.
- Evidence: Offer a reachable passing angle or exploit a third-player opening without running offside.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R03, R08; our adaptation, not an endorsed source drill.

## W1 · Wide two against one

- Family / level: Wide overload and box movement / 1
- Players: 2 outfield + 0 GK versus 1 outfield + 1 GK; 0 neutrals; **4 total**.
- Pitch: 26 × 20 m (editable starting design).
- Eligible career roles: LB, RB, LW, RW, 8, 9.
- Objective: A attacks goal; B can counter through either start gate.
- On turnover: Defender can counter; attacker must recover.
- Coach question: Who holds width if somebody runs inside?
- Player interactions: Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover.
- Evidence: Separate runs, preserve a reset, and choose cutback or carry from observed space.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R07; our adaptation, not an endorsed source drill.

## W2 · Overlap or stay

- Family / level: Wide overload and box movement / 2
- Players: 3 outfield + 0 GK versus 3 outfield + 1 GK; 0 neutrals; **7 total**.
- Pitch: 34 × 28 m (editable starting design).
- Eligible career roles: LB, RB, LW, RW, 8, 9.
- Objective: A attacks goal; B attacks two mini-goals.
- On turnover: Live counter after regain; swap asymmetric roles each round.
- Coach question: Who holds width if somebody runs inside?
- Player interactions: Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover.
- Evidence: Separate runs, preserve a reset, and choose cutback or carry from observed space.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R07; our adaptation, not an endorsed source drill.

## W3 · Far-side arrival

- Family / level: Wide overload and box movement / 3
- Players: 5 outfield + 1 GK versus 5 outfield + 1 GK; 0 neutrals; **12 total**.
- Pitch: 45 × 38 m (editable starting design).
- Eligible career roles: LB, RB, LW, RW, 8, 9.
- Objective: Normal goals; central and wide routes remain legal.
- On turnover: Track opposite winger and protecting midfielder on turnover.
- Coach question: Who holds width if somebody runs inside?
- Player interactions: Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover.
- Evidence: Separate runs, preserve a reset, and choose cutback or carry from observed space.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R01, R07; our adaptation, not an endorsed source drill.

## D1 · Delay and cover

- Family / level: Pressure, cover and balance / 1
- Players: 2 outfield + 0 GK versus 2 outfield + 0 GK; 0 neutrals; **4 total**.
- Pitch: 24 × 18 m (editable starting design).
- Eligible career roles: CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Two mini-goals per end.
- On turnover: Both pairs attack and defend continuously.
- Coach question: Can you win it, or should you slow the attack?
- Player interactions: First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle.
- Evidence: Delay or regain while a teammate covers; a foul or reckless chase is not success.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R06, R07, R12; our adaptation, not an endorsed source drill.

## D2 · Protect two threats

- Family / level: Pressure, cover and balance / 2
- Players: 3 outfield + 0 GK versus 3 outfield + 0 GK; 0 neutrals; **6 total**.
- Pitch: 30 × 26 m (editable starting design).
- Eligible career roles: CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Two mini-goals per end; free touches.
- On turnover: One pressures, one covers, one balances.
- Coach question: Can you win it, or should you slow the attack?
- Player interactions: First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle.
- Evidence: Delay or regain while a teammate covers; a foul or reckless chase is not success.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R06, R07, R12; our adaptation, not an endorsed source drill.

## D3 · Press as a unit

- Family / level: Pressure, cover and balance / 3
- Players: 4 outfield + 1 GK versus 4 outfield + 1 GK; 0 neutrals; **10 total**.
- Pitch: 42 × 30 m (editable starting design).
- Eligible career roles: CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Normal goals; no compulsory high press.
- On turnover: Regaining team chooses counter or secure pass.
- Coach question: Can you win it, or should you slow the attack?
- Player interactions: First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle.
- Evidence: Delay or regain while a teammate covers; a foul or reckless chase is not success.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R06, R07, R12; our adaptation, not an endorsed source drill.

## T1 · Win it and find space

- Family / level: React to a change of possession / 1
- Players: 3 outfield + 0 GK versus 3 outfield + 0 GK; 0 neutrals; **6 total**.
- Pitch: 28 × 22 m (editable starting design).
- Eligible career roles: CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Two mini-goals per end.
- On turnover: No automatic whistle after turnover.
- Coach question: Is there a safe counterpress, or do we recover?
- Player interactions: Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth.
- Evidence: Choose press or recovery using support and threat, not an unconditional countdown.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R07; our adaptation, not an endorsed source drill.

## T2 · Pressure with a spare

- Family / level: React to a change of possession / 2
- Players: 3 outfield + 0 GK versus 3 outfield + 0 GK; 1 neutrals; **7 total**.
- Pitch: 32 × 26 m (editable starting design).
- Eligible career roles: CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Opposite end-zone controlled reception.
- On turnover: Neutral switches only on settled possession; loose ball is contested.
- Coach question: Is there a safe counterpress, or do we recover?
- Player interactions: Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth.
- Evidence: Choose press or recovery using support and threat, not an unconditional countdown.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R07; our adaptation, not an endorsed source drill.

## T3 · Protect the counter

- Family / level: React to a change of possession / 3
- Players: 5 outfield + 1 GK versus 5 outfield + 1 GK; 0 neutrals; **12 total**.
- Pitch: 46 × 34 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6, 8, LW, RW, 9.
- Objective: Normal goals; reward quality in feedback, not forced fast shots.
- On turnover: Nearest effective pressure plus central recovery.
- Coach question: Is there a safe counterpress, or do we recover?
- Player interactions: Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth.
- Evidence: Choose press or recovery using support and threat, not an unconditional countdown.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R02, R07; our adaptation, not an endorsed source drill.

## F1 · Pass or finish

- Family / level: Create and finish / 1
- Players: 2 outfield + 0 GK versus 1 outfield + 1 GK; 0 neutrals; **4 total**.
- Pitch: 24 × 20 m (editable starting design).
- Eligible career roles: GK, LW, RW, 8, 9.
- Objective: A attacks goal; B attacks two exit gates.
- On turnover: Live defender counter and rebounds.
- Coach question: Is the shot better than the next pass?
- Player interactions: Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle.
- Evidence: Choose a feasible finish or better teammate; distinguish decision from shot execution.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R07, R08; our adaptation, not an endorsed source drill.

## F2 · Three finishers, two defenders

- Family / level: Create and finish / 2
- Players: 3 outfield + 0 GK versus 2 outfield + 1 GK; 0 neutrals; **6 total**.
- Pitch: 32 × 26 m (editable starting design).
- Eligible career roles: GK, LW, RW, 8, 9.
- Objective: A attacks goal; B attacks two mini-goals.
- On turnover: Attackers recover on loss; reset after out or goal.
- Coach question: Is the shot better than the next pass?
- Player interactions: Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle.
- Evidence: Choose a feasible finish or better teammate; distinguish decision from shot execution.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R07, R08; our adaptation, not an endorsed source drill.

## F3 · Finish under equal pressure

- Family / level: Create and finish / 3
- Players: 4 outfield + 1 GK versus 4 outfield + 1 GK; 0 neutrals; **10 total**.
- Pitch: 38 × 30 m (editable starting design).
- Eligible career roles: GK, LW, RW, 8, 9.
- Objective: Normal goals and live rebounds.
- On turnover: Both teams recover after shooting.
- Coach question: Is the shot better than the next pass?
- Player interactions: Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle.
- Evidence: Choose a feasible finish or better teammate; distinguish decision from shot execution.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R07, R08; our adaptation, not an endorsed source drill.

## K1 · Keeper plus outlets

- Family / level: Goalkeeper and back-line unit / 1
- Players: 2 outfield + 1 GK versus 2 outfield + 0 GK; 0 neutrals; **5 total**.
- Pitch: 28 × 24 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6.
- Objective: GK team exits through either gate; opponents attack goal.
- On turnover: GK may distribute after physical control only.
- Coach question: Protect the goal, defend space, or distribute?
- Player interactions: GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs.
- Evidence: Choose set, sweep or distribution from observed arrival and pressure.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R11, R02; our adaptation, not an endorsed source drill.

## K2 · Protect goal or space

- Family / level: Goalkeeper and back-line unit / 2
- Players: 2 outfield + 1 GK versus 2 outfield + 1 GK; 0 neutrals; **6 total**.
- Pitch: 34 × 24 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6.
- Objective: Normal goals; varied legal ground starts.
- On turnover: No scripted mandatory sweep; actual arrival decides.
- Coach question: Protect the goal, defend space, or distribute?
- Player interactions: GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs.
- Evidence: Choose set, sweep or distribution from observed arrival and pressure.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R11, R02; our adaptation, not an endorsed source drill.

## K3 · Keeper in the team

- Family / level: Goalkeeper and back-line unit / 3
- Players: 4 outfield + 1 GK versus 4 outfield + 1 GK; 0 neutrals; **10 total**.
- Pitch: 44 × 32 m (editable starting design).
- Eligible career roles: GK, CB, LB, RB, 6.
- Objective: Normal goals; varied short and advanced starts.
- On turnover: GK resets position as pressure and possession change.
- Coach question: Protect the goal, defend space, or distribute?
- Player interactions: GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs.
- Evidence: Choose set, sweep or distribution from observed arrival and pressure.
- Easier: Use the resolved actor task: attack may gain width; defense may narrow targets; GK may move attacker start farther away. Verify one geometry change before use.
- Harder: Review the next format separately; never change numbers, targets and geometry mid-bout without a verified layout.
- Transfer: Remove practice incentives; observe the same decision in a normal 9v9 match.
- Research basis: R11, R02; our adaptation, not an endorsed source drill.

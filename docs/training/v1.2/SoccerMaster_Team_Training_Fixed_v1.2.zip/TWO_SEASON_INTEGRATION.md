# v1.1 — 108-session expansion

Historical v1.1 integration contract. FIXES_v1.2.md overrides its API examples, season identity mechanism, scenario capabilities, role feedback and test counts. Use the scheduled-run factory and structured exact-definition approvals in v1.2; string capabilities and bare week IDs are no longer accepted by that path.

Two seasons, eighteen weeks each, three team-training sessions per week: 54 per season and 108 total. This replaces the eight-week sketch as the full content schedule. The 24 original game formats remain building blocks. Every scheduled slot now has its own football situation, coaching question, evidence focus and 9v9 transfer question.

## Season structure

Season one weeks 1–6 establish support, pressure, cover and build-up; weeks 7–12 connect midfield, switching, wide play, finishing and recovery; weeks 13–18 connect goalkeeper and units, match context and transfer. Week 9 checks retention; week 18 reviews season evidence.

Season two reassesses retained ability, then varies presses, compact defending, rotations, overload defense, rest defense, run timing, unequal recovery and match risk. Weeks 9 and 18 again check transfer. Neither the season boundary nor calendar week grants mastery or attribute increases.

The level cap in season one is 1 for weeks 1–6, 2 for weeks 7–12 and 3 for weeks 13–18. Season two permits levels 1–3. `earnedLevel` still controls actual selection; an unfamiliar player in season two can use level 1. These caps are authored pacing defaults, not biological age or clinical ability classifications. A future cap adjustment must be explicit content configuration.

## Implementation

Import `sessions` and `planSession` from `seasons.mjs`. Register the full schedule in existing story training slots. Session ID includes season, week and slot, e.g. S2-W04-B. Each role has a published primary or complementary route. A keeper practicing a team's switching theme may work on distribution/reset support in the keeper family. This is explicitly labeled; it does not silently turn the keeper into a winger.

The scenario capability is separate from the base practice capability. A working S1 mini-goal game does not mean every scheduled switching setup works. `planSession` requires the exact role variant ID to be enabled and then checks the underlying game capability/roster. Author the physical starts and complementary role setup against the actual field. If a described scenario is not feasible at the selected base level, use a reviewed level-appropriate version of that same problem or report unavailable. Do not add phantom players to recreate a complete team shape in 3v3.

For asymmetric cards, author the actual attacking or defending career assignment and swapped field setup where required. The generic reference assignment function places the human in the first eligible slot; it does not implement those scenario-specific assignments. Do not enable an underloaded-defender scenario until the player actually starts in the underloaded unit. A full 9v9 press/formation is represented by its local relationship in a small game; full formation transfer is tested separately in matches.

The baseline scenario is only a starting arrangement and opponent intention. Never force an interception, heavy touch, goal, player error or fixed success path to make the exercise happen. For turnover sessions, use live opposition and capture an actual control change. If the desired opportunity does not occur, report insufficient evidence and adjust a later start.

## Save identity and entitlements

Use the existing globally unique scheduled training event identity. It MUST distinguish career, season, week and slot. The original reference run API's `weekId` must receive a season-qualified schedule identifier, such as `S2-W04`, rather than the bare number `4`. Otherwise its completion tuple can collide between seasons. Map this to the existing entitlement service; do not establish a second reward stream. Retried drill IDs, variants, seeds and practice-run IDs never mint another weekly entitlement.

Bind the curriculum session ID, role variant ID and content version to the run. Validate them when loading and completing. If story rescheduling moves a training slot, preserve its entitlement identity and committed result. Season rollover does not clear consumed rewards or history. No duplicate credit from playing a session-one variant in season two. Future curriculum changes require a versioned schedule migration.

## Three weekly slots and competition load

This expansion retains the established three-session week. Bind the season weeks to current story fixtures, travel, school scenes and tournaments. The curriculum does not move tournaments or change standings. If the schedule has a congested weekend, the host can reduce duration, use a lower-load version, or reschedule while retaining identity. Do not invent a completed session, invent recovery, or silently remove the week's focus. Competition-preparation weeks are generic; actual fixture dates take precedence.

Home juggling, optional skills, recess games and matches remain separate activities. Their combined progression and energy impact belongs to the existing progression model. The 108 sessions do not create 108 automatic attribute boosts.

## Delivery and test scope

`TWO_SEASON_PROGRAM.md` is the readable 108-session handbook. `season-sessions.json` is its generated data source for import. `seasons.mjs` authors the schedule and routes; `build-seasons.mjs` regenerates the handbook/JSON. `seasons.test.mjs` checks the complete inventory, all role mappings, scenario capability gating, level gating and season identity.

22 reference tests now pass: the previous 16 plus six curriculum checks. All 108 scenario starts and complementary role implementations still require host authoring, scene integration and gameplay acceptance. This package does not claim those live-game tests passed. The prior research remains the basis; this turn expands authored content rather than claiming new research findings.

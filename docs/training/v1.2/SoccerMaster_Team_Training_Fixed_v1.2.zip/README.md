# SoccerMaster team-training engine v1.2 — audited corrections

Built 21 October 2026 for small-sided tactical learning that connects to U11–U12 9v9.

Read **FIXES_v1.2.md** first: it supersedes older API, save, completion and adaptation instructions. **TWO_SEASON_PROGRAM.md** contains 108 sessions across 36 weeks with role-specific questions. **scenario-layouts.json** contains versioned actor/target reference layouts, including local overloads. **RESEARCH.md** and **PRACTICE_CARDS.md** provide the research and 24 game formats. Historical documents are retained and explicitly marked where superseded. All 36 current reference tests pass.

## Run

```sh
node --test engine.test.mjs seasons.test.mjs regressions.test.mjs
node build-cards.mjs
node build-seasons.mjs
```

No external packages. Modern JavaScript ES modules; Node is used for verification and card generation. `engine.mjs` and `catalog.mjs` can be imported by a browser build that supports structuredClone. Inspect current project compatibility before integrating.

```js
import {planSession, createScheduledRun} from './seasons.mjs';
// roster and verified records come from the existing game adapter.
const plan = planSession({sessionId:'S1-W02-A',role:'RW',earnedLevel:1,
  players:roster,humanId:savedPlayerId,rulesProfile:'youth',
  practiceCapabilities:verifiedPracticeIds,scenarioCapabilities:verifiedScenarioRecords});
if (plan.status === 'selected') {
  const run = createScheduledRun({plan,careerId,runId,seed:17,boutSeconds:90});
  // Persist bound run through the existing save service before play.
}
```

This is a working reference training coordinator and authored content pack. It is not a playable scene, player AI, ball simulator, persistent reward store, or proof of educational effectiveness. It emits no attribute gains. Host geometry, scoring rules, tactical evidence detectors, scene rendering and transactional integration remain necessary. No old project files were replaced and no GitHub/Cloudflare deployment was performed.

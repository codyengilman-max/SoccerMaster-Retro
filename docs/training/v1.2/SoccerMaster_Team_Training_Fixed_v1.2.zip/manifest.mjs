import {readdirSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const files={};
for(const file of readdirSync(new URL('.',import.meta.url),{withFileTypes:true})) {
 if(!file.isFile()||file.name==='MANIFEST.json') continue;
 const bytes=readFileSync(new URL(file.name,import.meta.url));
 files[file.name]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};
}
writeFileSync(new URL('MANIFEST.json',import.meta.url),JSON.stringify({scope:'Root deliverables excluding manifest itself and Git metadata',files},null,2)+'\n');

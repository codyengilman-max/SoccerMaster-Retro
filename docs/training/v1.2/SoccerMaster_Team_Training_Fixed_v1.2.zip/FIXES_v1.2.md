# v1.2 corrected handoff — start here

21 October 2026. This file supersedes conflicting v1.0/v1.1 implementation instructions. The 108-session curriculum, 24 underlying game formats and original research remain. The current release contains 36 passing reference tests.

## Audit dispositions

| Finding | Correction in this package | Remaining game-level verification |
|---|---|---|
| RT01: season/scenario identity | Scheduled-run factory binds explicit season, qualified week, slot, curriculum session, variant, practice, rules and versions. Completion checks that entire context. Ambiguous week and missing season are rejected. | Map the explicit tuple to the existing transactional entitlement service; migrate old saves without duplicate awards. |
| RT02: pause callbacks | Pause, resume and round-end advance generation. Pre-pause evidence/ticks are rejected after resume. | Persist already committed pending work and reconcile it explicitly; canceled callbacks cannot be used as reconciliation. |
| RT03: roster mismatch | Selector checks keeper AND outfield availability. Planner takes actual roster and assigns actors before returning selected. GK transition curriculum routes to keeper cards; zero-GK cards exclude GK roles. | Actual scene uses returned actors and preserves control ownership. |
| RT04: broad capability | Approval requires an exact structured definition, including practice/level, rules, curriculum/scenario/layout versions and actual actor/target layout. A level-one record cannot enable level three. | Only a tested adapter may populate the verified registry; never mark generated layouts verified automatically. |
| RT05: event saturation | Deduplicate evidence on ingestion by actor/opportunity/dimension; cap unique evidence at 512; bound command history and participation. Overflow marks telemetry degraded while lifecycle actions remain available. | Surface recoverable telemetry failure and do not award credit from degraded data. |
| RT06: difficulty | Recommendation accepts actor task. Attack, defense and keeper have different single-variable recipes. Next format is proposed for review, not auto-promoted. Reduced bouts are configured before run creation. | Validate the adjusted geometry and practical difficulty; re-register changed layouts rather than mutate a live approved setup. |
| RT07: idle completion | Attendance, participation, telemetry and mastery are distinct outputs. Clock-only completion cannot qualify for credit. Observed off-ball contribution can qualify without tactical mastery evidence. | Apply existing reward amounts only when permitted; host telemetry must reflect actual participation. |
| RT08: wrong role feedback | Planner resolves role-specific scenario, question and evidence. Keeper feedback stays keeper-specific; complementary CB finishing work gets defending feedback. Handbook contains resolved role tables. | UI uses resolved plan fields rather than the primary-family text. |
| RT09: tactical setup gaps | Versioned actor layouts specify actual slots, human side, starts, ball owner, targets and duties. Local-overload layouts for S1-W12-B / S2-W07-A / S2-W12-B put the human in front of recovering cover against two attackers. Full-team concepts are labeled transfer context. | Check all enabled starts against actual movement, target geometry and rules. Other session-specific coaching contexts still need a reviewed scene adapter. |

## Correct integration path

1. Use `scenarioDefinition(sessionId, role, level, rulesProfile)` to obtain the exact reference definition for authoring/testing. It contains normalized actor/target coordinates, explicit physical widths for mini-goals/gates, and host-goal-width placeholders. Resolve placeholders from the host rules. `scenario-layouts.json` uses the placeholder rules profile `reference`, not a verified competition ruleset.
2. Test the actual scene. Only then add `{key: definition.key, verified: true, definition}` to the host registry. Registry data is trusted build configuration, never user input or saved player claims. Exact structural comparison is intentionally conservative. A changed layout/rules/content revision must be revalidated. These records are capability checks, not cryptographic signatures.
3. Call `planSession` with actual `players`, human ID and current role. It selects the permitted level, validates roster feasibility, allocates actors and returns resolved instructions. A missing or stale approval stays unavailable. The actor list assigns only physically present participants; bench actors remain outside that scene.
4. Use `createScheduledRun({plan, careerId, runId, seed, boutSeconds})`. Do not assemble a run manually from bare week/slot strings. Save and later compare the bound context; `completionRequest(run, currentBoundContext)` requires all of career, season, qualified week, slot, session, variant, layout key, rules profile, curriculum/scenario/practice versions, human and practice identity.
5. Persist outcomes through the existing transactional progression service. Use `[careerId, seasonId, weekId, slotId]` as the reference identity, mapped to the host's canonical scheduled-event key. Do not create an additional reward stream. Run ID, seed and drill retries cannot mint another entitlement.

The lower-level createRun remains exported for tests/adapters and validates required identity fields. The scheduled factory is the curriculum entry point and validates the chosen practice against its scenario. These APIs assume trusted host state; they are not a network authorization boundary.

## Completion and participation policy

Every fully completed run returns attendanceComplete. `creditEligible` additionally requires at least 30 seconds of observed active involvement and healthy telemetry without evidence-capacity overflow. This is a conservative game participation gate, not a researched mastery threshold or a reward amount. It applies to the whole three-bout run, including configured shorter bouts. Existing story attendance requirements may record attendance separately; attribute or training credit must honor creditEligible before calling existing progression rules.

Host `participation` events include actorId (must be the human), unique windowId, kind (`active-play` or `off-ball-support`), observable true, start/end in cumulative active simulation seconds. Each window must be positive, no longer than five seconds, within elapsed play, and non-overlapping. Positioning, useful recovery and support can count; merely holding a key or moving aimlessly cannot. The host detector must establish this. Repeated/overlapping windows never add time twice.

Host `telemetry` events declare healthy/degraded. Unknown, degraded or overflowing telemetry never qualifies for credit. Completion still reports attendance and a recoverable diagnostic. Tactical evidence remains opportunity-based and requires five valid opportunities per dimension before showing a score. `masteryGranted` is always false here; long-term skill progression belongs to the existing service with transfer evidence. No tactical opportunities is not itself a failure of participation.

## Lifecycle and limits

Use the current generation on every event; pause/resume and automatic round-end invalidate queued uncommitted callbacks. Committed actions waiting on evaluation require a durable host pending-work record. Reconcile each once into the new generation using its original opportunity identity; do not relabel arbitrary stale callbacks. Duplicate opportunity data remains idempotent.

The reducer caps unique evidence at 512, participation windows at 512 and recent command IDs at 256. Saturation reports degraded telemetry and preserves pause/abort. No auto-credit on overflow. Active time advances only through bounded fixed-step ticks; paused/render time contributes nothing. New runs accept 30–90 seconds per bout; do not change duration midway through a persisted run.

Save format is now version 2. Version-1 saves fail explicitly and require host migration. Resolve the original canonical scheduled identity and committed outcome from trusted save records; do not guess its season from whichever season is on screen. Preserve already consumed entitlements. If an old run cannot be resolved, show a recovery state without claiming it completed or creating another reward. The current game save format was not supplied, so an actual migration cannot be implemented safely in this standalone package.

## Geometry and tactics

Actors have normalized starts plus resolved metre positions, side and individual task. A attacks toward x=length, B toward x=0; convert through the host's orientation transform before rendering/physics. Keeper starts and ball ownership are explicit. Target definitions distinguish full goals, mini-goals, gates and end zones; the host must implement physical crossing/receiving predicates and restart rules. Goal width comes from host rules, not a guessed regulation.

The local-overload variant uses normal full participation: two attackers begin ahead of recovering cover while one human defender delays. No spawning, forced error or instant recovery is used. All players are active from time zero and normal speed decides when cover arrives. Reference positions are geometrically valid; actual arrival timing and offside legality must be checked against the host's rules/attributes before approval.

Layouts generated for other curriculum slots are concrete starting templates, not proof of a fully authored or playable specialized scenario. Their free-text weekly problem must still be realized by the host adapter. Only enable exact verified records. This closes the unsafe selection/assignment assumptions while keeping remaining scene work visible.

## Verification and handoff

Run `node --test engine.test.mjs seasons.test.mjs regressions.test.mjs`. The exhaustive curriculum test performs selection AND assignment for every session/role/allowed level: 2,430 combinations. Test capability approvals are deliberately synthetic fixtures and are never shipped as live verified registry entries. Regression tests cover actual completion identities, stale pause events, 10,000 duplicate opportunities, distinct-evidence overflow, keeper slots, role feedback, overload positions, idle credit and meaningful off-ball participation.

36 tests pass. Live physics, UI, AI responsiveness, persistence concurrency/migration and physical iPhone tests remain NOT RUN. Keep all scenario capabilities disabled until their host acceptance checks pass. Current files constitute a corrected reference coordinator and content package, not a production certification.

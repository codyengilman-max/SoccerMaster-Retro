import {writeFileSync} from 'node:fs';
import {catalog,families} from './catalog.mjs';
let text='# SoccerMaster — 24 small-sided practice cards\n\nOriginal reference designs; provisional geometry and game-time dose. See DEVIN_HANDOFF.md for shared rules, telemetry and adapter requirements. All cards are reference prototypes until live implementation is verified. Sources refer to RESEARCH.md.\n';
for(const d of catalog) {
 const f=families[d.family],p=d.participants;
 text+=`\n## ${d.id} · ${d.name}\n\n`+
 `- Family / level: ${f.name} / ${d.level}\n`+
 `- Players: ${p.outfieldA} outfield + ${p.gkA} GK versus ${p.outfieldB} outfield + ${p.gkB} GK; ${p.neutrals} neutrals; **${p.total} total**.\n`+
 `- Pitch: ${d.pitch.length} × ${d.pitch.width} m (editable starting design).\n`+
 `- Eligible career roles: ${d.roles.join(', ')}.\n`+
 `- Objective: ${d.objective}.\n`+
 `- On turnover: ${d.turnover}.\n`+
 `- Coach question: ${f.cue}\n`+
 `- Player interactions: ${f.behaviors.join('; ')}.\n`+
 `- Evidence: ${f.evidence}.\n`+
 `- Easier: ${d.regression}.\n`+
 `- Harder: ${d.progression}.\n`+
 `- Transfer: ${d.transfer}.\n`+
 `- Research basis: ${d.sources.join(', ')}; our adaptation, not an endorsed source drill.\n`;
}
writeFileSync(new URL('./PRACTICE_CARDS.md',import.meta.url),text);
writeFileSync(new URL('./catalog.json',import.meta.url),JSON.stringify(catalog,null,2)+'\n');

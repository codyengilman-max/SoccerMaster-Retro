# SoccerMaster — two-season team-training program

18 weeks per season × three sessions per week = 108 scheduled sessions. Each entry is an authored scenario using a supported small-sided game. These are 108 session plans built on 24 base practice cards, not 108 verified live-game implementations. Role routes are mappings, not claims of 972 independently authored drills.

## Season 1

| Week | Team theme | Session A | Session B | Session C |
|---|---|---|---|---|
| 1 | Find space and recognize pressure | Play out under pressure | Receive, support and combine | Pressure, cover and balance |
| 2 | Width, depth and a safe reset | Draw pressure and switch | Play out under pressure | Receive, support and combine |
| 3 | Draw a defender and release | Wide overload and box movement | Receive, support and combine | Create and finish |
| 4 | First defender and cover | Pressure, cover and balance | React to a change of possession | Play out under pressure |
| 5 | First touch opens the next action | Receive, support and combine | Play out under pressure | Create and finish |
| 6 | Play around the first press | Play out under pressure | Goalkeeper and back-line unit | Draw pressure and switch |
| 7 | Midfield support and third player | Receive, support and combine | Play out under pressure | Pressure, cover and balance |
| 8 | Switch when the picture changes | Draw pressure and switch | Wide overload and box movement | React to a change of possession |
| 9 | Midseason retention check | Play out under pressure | Pressure, cover and balance | Draw pressure and switch |
| 10 | Wide partnerships | Wide overload and box movement | Receive, support and combine | Pressure, cover and balance |
| 11 | Create chances together | Create and finish | Wide overload and box movement | Goalkeeper and back-line unit |
| 12 | Recover after losing the ball | React to a change of possession | Pressure, cover and balance | Play out under pressure |
| 13 | Goalkeeper as part of the team | Goalkeeper and back-line unit | Play out under pressure | Create and finish |
| 14 | Front line pressure | Pressure, cover and balance | React to a change of possession | Receive, support and combine |
| 15 | Counter or keep it | React to a change of possession | Create and finish | Draw pressure and switch |
| 16 | Connected units | Play out under pressure | Wide overload and box movement | Pressure, cover and balance |
| 17 | Competition preparation | Draw pressure and switch | Pressure, cover and balance | Goalkeeper and back-line unit |
| 18 | Season-one transfer and review | Receive, support and combine | React to a change of possession | Create and finish |

### S1-W01-A — Find space and recognize pressure: Play out under pressure

**Football situation:** GK starts with two short outlets; nearest opponent chooses which outlet to press.

**Game choice:** B1 (Find the exit, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the player look for useful space before moving toward the ball?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W01-B — Find space and recognize pressure: Receive, support and combine

**Football situation:** Receiver begins behind a defender and must create a visible passing angle.

**Game choice:** C1 (Give and go or turn, 5 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the player look for useful space before moving toward the ball?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W01-C — Find space and recognize pressure: Pressure, cover and balance

**Football situation:** Two defenders begin staggered; attack can choose either mini-goal.

**Game choice:** D1 (Delay and cover, 4 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the player look for useful space before moving toward the ball?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W02-A — Width, depth and a safe reset: Draw pressure and switch

**Football situation:** Ball starts near one touchline; far target is available but not automatically preferable.

**Game choice:** S1 (Two goals to choose, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are teammates offering different angles rather than clustering?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W02-B — Width, depth and a safe reset: Play out under pressure

**Football situation:** First forward outlet is screened; GK and near back provide different reset angles.

**Game choice:** B1 (Find the exit, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are teammates offering different angles rather than clustering?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W02-C — Width, depth and a safe reset: Receive, support and combine

**Football situation:** Two attackers start on the same line and must create staggered support.

**Game choice:** C1 (Give and go or turn, 5 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are teammates offering different angles rather than clustering?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W03-A — Draw a defender and release: Wide overload and box movement

**Football situation:** Wide carrier faces a defender who may hold position or step toward the ball.

**Game choice:** W1 (Wide two against one, 4 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does a pass exploit a defender movement rather than happen by habit?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S1-W03-B — Draw a defender and release: Receive, support and combine

**Football situation:** Support player can check short or run beyond when the defender commits.

**Game choice:** C1 (Give and go or turn, 5 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does a pass exploit a defender movement rather than happen by habit?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W03-C — Draw a defender and release: Create and finish

**Football situation:** Two attackers face one defender and GK; carrier chooses pass or shot.

**Game choice:** F1 (Pass or finish, 4 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does a pass exploit a defender movement rather than happen by habit?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S1-W04-A — First defender and cover: Pressure, cover and balance

**Football situation:** Ball carrier starts centrally; first defender must approach without opening the inside lane.

**Game choice:** D1 (Delay and cover, 4 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the second defender cover instead of duplicating pressure?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W04-B — First defender and cover: React to a change of possession

**Football situation:** Begin with an ordinary opposed attack; on an actual loss, the closest player checks for cover.

**Game choice:** T1 (Win it and find space, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the second defender cover instead of duplicating pressure?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W04-C — First defender and cover: Play out under pressure

**Football situation:** Build-up unit faces one active presser and a second defender screening midfield.

**Game choice:** B1 (Find the exit, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the second defender cover instead of duplicating pressure?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W05-A — First touch opens the next action: Receive, support and combine

**Football situation:** Receiver approaches at an angle while a defender closes from one side.

**Game choice:** C1 (Give and go or turn, 5 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does receiving position preserve a usable next option?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W05-B — First touch opens the next action: Play out under pressure

**Football situation:** GK passes to a back whose forward route can be open or screened.

**Game choice:** B1 (Find the exit, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does receiving position preserve a usable next option?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W05-C — First touch opens the next action: Create and finish

**Football situation:** Attacker receives with back partly to goal and chooses turn, set or retain.

**Game choice:** F1 (Pass or finish, 4 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does receiving position preserve a usable next option?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S1-W06-A — Play around the first press: Play out under pressure

**Football situation:** Striker curves the press toward one back; other defenders respond normally.

**Game choice:** B1 (Find the exit, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team escape pressure without forcing the first forward pass?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W06-B — Play around the first press: Goalkeeper and back-line unit

**Football situation:** GK is offered a near return and a more distant outlet under live pressure.

**Game choice:** K1 (Keeper plus outlets, 5 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team escape pressure without forcing the first forward pass?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W06-C — Play around the first press: Draw pressure and switch

**Football situation:** Near target is defended; attack can reset centrally before accessing the opposite target.

**Game choice:** S1 (Two goals to choose, 6 players). Select only the player's earned level up to this session's cap of 1; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team escape pressure without forcing the first forward pass?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W07-A — Midfield support and third player: Receive, support and combine

**Football situation:** Central receiver is followed; another attacker can become the third-player outlet.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the supporting player make the next pass easier before receiving?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W07-B — Midfield support and third player: Play out under pressure

**Football situation:** Holding midfielder begins in a cover shadow and must find a usable angle.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the supporting player make the next pass easier before receiving?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W07-C — Midfield support and third player: Pressure, cover and balance

**Football situation:** Defenders protect a central receiver while maintaining access to the ball.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the supporting player make the next pass easier before receiving?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W08-A — Switch when the picture changes: Draw pressure and switch

**Football situation:** Defending unit shifts toward the ball; far-side space changes as play continues.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Is the switch selected because it improves access?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W08-B — Switch when the picture changes: Wide overload and box movement

**Football situation:** Winger receives a switch with defender recovering; choose attack or secure possession.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Is the switch selected because it improves access?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S1-W08-C — Switch when the picture changes: React to a change of possession

**Football situation:** A wide attack may break down; opposite players must protect central space.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Is the switch selected because it improves access?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W09-A — Midseason retention check: Play out under pressure

**Football situation:** Revisit the week-one build-up problem with mirrored starting positions and no cue overlay.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do earlier behaviors appear without an instruction immediately beforehand?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W09-B — Midseason retention check: Pressure, cover and balance

**Football situation:** Revisit pressure-cover against a different pair of attackers without telling who presses.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do earlier behaviors appear without an instruction immediately beforehand?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W09-C — Midseason retention check: Draw pressure and switch

**Football situation:** Two-target game uses normal scoring and no switch bonus.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do earlier behaviors appear without an instruction immediately beforehand?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W10-A — Wide partnerships: Wide overload and box movement

**Football situation:** Winger holds width; supporting back chooses underneath support or a feasible outside run.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are winger and back making complementary movements?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S1-W10-B — Wide partnerships: Receive, support and combine

**Football situation:** Winger checks inside while another player can maintain the wide outlet.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are winger and back making complementary movements?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W10-C — Wide partnerships: Pressure, cover and balance

**Football situation:** Outside defender faces a carrier and support runner; cover protects the inside route.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are winger and back making complementary movements?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W11-A — Create chances together: Create and finish

**Football situation:** Carrier attacks centrally with one teammate available for a square pass.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack preserve the better finish instead of forcing a shot?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S1-W11-B — Create chances together: Wide overload and box movement

**Football situation:** Ball reaches a wide scoring area; near and deeper runners choose separate lanes.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack preserve the better finish instead of forcing a shot?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S1-W11-C — Create chances together: Goalkeeper and back-line unit

**Football situation:** GK faces an attacker with a passing option and adjusts to ball angle.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack preserve the better finish instead of forcing a shot?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W12-A — Recover after losing the ball: React to a change of possession

**Football situation:** Attacking team has players ahead of the ball when an opponent genuinely wins possession.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team protect the middle when immediate pressure is unsupported?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W12-B — Recover after losing the ball: Pressure, cover and balance

**Football situation:** Defender begins outnumbered and must delay while support recovers.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team protect the middle when immediate pressure is unsupported?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W12-C — Recover after losing the ball: Play out under pressure

**Football situation:** After winning possession near goal, compare a safe outlet and an ambitious forward pass.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players). Select only the player's earned level up to this session's cap of 2; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team protect the middle when immediate pressure is unsupported?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W13-A — Goalkeeper as part of the team: Goalkeeper and back-line unit

**Football situation:** Opposing carrier has space; GK chooses position from pressure and possible through-ball.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do goalkeeper and back line support one another before and after the shot?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W13-B — Goalkeeper as part of the team: Play out under pressure

**Football situation:** GK receives a reset while the first outlet is pressed and another angle develops.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do goalkeeper and back line support one another before and after the shot?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W13-C — Goalkeeper as part of the team: Create and finish

**Football situation:** A live attack can produce a rebound; attackers and GK continue until the ball is dead.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do goalkeeper and back line support one another before and after the shot?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S1-W14-A — Front line pressure: Pressure, cover and balance

**Football situation:** Front attacker curves pressure toward a chosen side while teammates protect exits.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the front press guide play with support rather than chase alone?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W14-B — Front line pressure: React to a change of possession

**Football situation:** High regain creates a brief opening; compare early attack and secure possession.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the front press guide play with support rather than chase alone?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W14-C — Front line pressure: Receive, support and combine

**Football situation:** Opposition escapes the press; attackers practice finding a new support angle.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the front press guide play with support rather than chase alone?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W15-A — Counter or keep it: React to a change of possession

**Football situation:** Regain occurs with a forward runner available but a defender able to intercept.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players recognize when the initial counterattack has ended?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W15-B — Counter or keep it: Create and finish

**Football situation:** A recovering defender approaches the shooting lane; compare pass and finish.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players recognize when the initial counterattack has ended?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S1-W15-C — Counter or keep it: Draw pressure and switch

**Football situation:** Counter route closes and a far-side reset becomes available.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players recognize when the initial counterattack has ended?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W16-A — Connected units: Play out under pressure

**Football situation:** Back-line outlet connects to midfield, which must support a second forward action.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are the back, midfield and attack connected by reachable passing distances?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W16-B — Connected units: Wide overload and box movement

**Football situation:** Wide penetration requires a covering teammate to remain behind the attack.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are the back, midfield and attack connected by reachable passing distances?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S1-W16-C — Connected units: Pressure, cover and balance

**Football situation:** Defense shifts across two threats while protecting the route to goal.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are the back, midfield and attack connected by reachable passing distances?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W17-A — Competition preparation: Draw pressure and switch

**Football situation:** Opponent protects central space; attack must compare wide access and patient circulation.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do decisions remain appropriate when score and time provide context?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S1-W17-B — Competition preparation: Pressure, cover and balance

**Football situation:** Short match scenario begins level late in the game; choose sensible pressing risk.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do decisions remain appropriate when score and time provide context?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W17-C — Competition preparation: Goalkeeper and back-line unit

**Football situation:** Keeper distribution begins after a save while teammates recover their structure.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do decisions remain appropriate when score and time provide context?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S1-W18-A — Season-one transfer and review: Receive, support and combine

**Football situation:** Remove coaching overlays and revisit a support problem with an unfamiliar starting side.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which behaviors transfer into normal 9v9 and which need next-season practice?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S1-W18-B — Season-one transfer and review: React to a change of possession

**Football situation:** Play continuous turnovers with ordinary scoring and no speed bonus.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which behaviors transfer into normal 9v9 and which need next-season practice?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S1-W18-C — Season-one transfer and review: Create and finish

**Football situation:** Finish in equal-number play at the highest individually supported level.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which behaviors transfer into normal 9v9 and which need next-season practice?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

## Season 2

| Week | Team theme | Session A | Session B | Session C |
|---|---|---|---|---|
| 1 | Return, reassess and reconnect | Play out under pressure | Pressure, cover and balance | Receive, support and combine |
| 2 | Recognize different presses | Play out under pressure | Goalkeeper and back-line unit | Draw pressure and switch |
| 3 | Invite pressure without losing control | Play out under pressure | Receive, support and combine | React to a change of possession |
| 4 | Switch, then attack the new side | Draw pressure and switch | Wide overload and box movement | Create and finish |
| 5 | Rotations with clear responsibility | Receive, support and combine | Wide overload and box movement | Pressure, cover and balance |
| 6 | Break a compact middle | Receive, support and combine | Draw pressure and switch | Create and finish |
| 7 | Defend an overload | Pressure, cover and balance | Goalkeeper and back-line unit | React to a change of possession |
| 8 | Pressing triggers and escape routes | Pressure, cover and balance | Play out under pressure | React to a change of possession |
| 9 | Midseason transfer under variation | Draw pressure and switch | Receive, support and combine | Pressure, cover and balance |
| 10 | Rest defense supports attack | Wide overload and box movement | React to a change of possession | Pressure, cover and balance |
| 11 | Timing depth and the second striker | Receive, support and combine | Wide overload and box movement | Create and finish |
| 12 | Transitions with unequal recovery | React to a change of possession | Pressure, cover and balance | Goalkeeper and back-line unit |
| 13 | Solve different defensive shapes | Play out under pressure | Draw pressure and switch | Receive, support and combine |
| 14 | Manage match risk | React to a change of possession | Play out under pressure | Create and finish |
| 15 | Restarts into open play | Play out under pressure | Goalkeeper and back-line unit | Pressure, cover and balance |
| 16 | Execute with less help | Receive, support and combine | Draw pressure and switch | React to a change of possession |
| 17 | Competition rehearsal | Pressure, cover and balance | Wide overload and box movement | Goalkeeper and back-line unit |
| 18 | Season-two transfer and next steps | Play out under pressure | React to a change of possession | Create and finish |

### S2-W01-A — Return, reassess and reconnect: Play out under pressure

**Football situation:** New teammate pairings face the original outlet problem; no assumed mastery from last season.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which retained behaviors survive a different opponent and teammate pairing?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W01-B — Return, reassess and reconnect: Pressure, cover and balance

**Football situation:** Defensive pair faces an attacker who changes pace and direction within normal attributes.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which retained behaviors survive a different opponent and teammate pairing?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W01-C — Return, reassess and reconnect: Receive, support and combine

**Football situation:** Receiver and supporting player solve a mirrored third-player problem without a cue.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which retained behaviors survive a different opponent and teammate pairing?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W02-A — Recognize different presses: Play out under pressure

**Football situation:** Compare one pressing forward with an authored two-forward press in a supported card.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team adapt to the actual press rather than repeat one exit?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W02-B — Recognize different presses: Goalkeeper and back-line unit

**Football situation:** GK sees opponents screen short outlets and must identify a feasible remaining option.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team adapt to the actual press rather than repeat one exit?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W02-C — Recognize different presses: Draw pressure and switch

**Football situation:** Opponent blocks the return route, making same-side progression or a longer reset meaningful.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team adapt to the actual press rather than repeat one exit?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W03-A — Invite pressure without losing control: Play out under pressure

**Football situation:** Back carries into free space while an opponent chooses when to engage.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team draw pressure while preserving a credible escape?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W03-B — Invite pressure without losing control: Receive, support and combine

**Football situation:** Receiver sets back to a third player only if the forward turn is genuinely closed.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team draw pressure while preserving a credible escape?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W03-C — Invite pressure without losing control: React to a change of possession

**Football situation:** An invited press wins the ball occasionally; nearby players react without a scripted regain.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team draw pressure while preserving a credible escape?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W04-A — Switch, then attack the new side: Draw pressure and switch

**Football situation:** Far-side outlet becomes available as defense shifts, then closes if the pass is delayed.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the receiver exploit the advantage before it disappears?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W04-B — Switch, then attack the new side: Wide overload and box movement

**Football situation:** Winger receives with a recovering outside defender and a teammate supporting underneath.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the receiver exploit the advantage before it disappears?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S2-W04-C — Switch, then attack the new side: Create and finish

**Football situation:** Attack reaches the box after a switch; compare cutback, carry and shot.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the receiver exploit the advantage before it disappears?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S2-W05-A — Rotations with clear responsibility: Receive, support and combine

**Football situation:** 9 checks toward the ball; winger or 8 can provide depth if the lane opens.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does someone replace the space vacated by a teammate?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W05-B — Rotations with clear responsibility: Wide overload and box movement

**Football situation:** Winger enters an inside channel while a back retains width and another player covers.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does someone replace the space vacated by a teammate?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S2-W05-C — Rotations with clear responsibility: Pressure, cover and balance

**Football situation:** Defenders hand over a crossing runner using visible movement instead of following indefinitely.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does someone replace the space vacated by a teammate?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W06-A — Break a compact middle: Receive, support and combine

**Football situation:** Opposition protects the central lane; receive between lines only when reachable.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does patience create a better route without becoming pointless circulation?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W06-B — Break a compact middle: Draw pressure and switch

**Football situation:** Central route remains blocked while wide targets can stretch the defending unit.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does patience create a better route without becoming pointless circulation?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W06-C — Break a compact middle: Create and finish

**Football situation:** Attack faces defenders near goal; compare a blocked shot with a usable extra pass.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does patience create a better route without becoming pointless circulation?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S2-W07-A — Defend an overload: Pressure, cover and balance

**Football situation:** Use a supported asymmetric game with the career defender in the underloaded unit.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do defenders delay and protect danger rather than all attack the ball?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W07-B — Defend an overload: Goalkeeper and back-line unit

**Football situation:** GK supports a recovering defender against a carrier plus runner.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do defenders delay and protect danger rather than all attack the ball?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W07-C — Defend an overload: React to a change of possession

**Football situation:** An outnumbered defense wins possession and needs a secure first outlet.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do defenders delay and protect danger rather than all attack the ball?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W08-A — Pressing triggers and escape routes: Pressure, cover and balance

**Football situation:** A genuine heavy touch or backward reception can trigger pressure when cover exists.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players start and stop a press for observable reasons?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W08-B — Pressing triggers and escape routes: Play out under pressure

**Football situation:** Build-up team responds to pressure triggered by its visible first touch.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players start and stop a press for observable reasons?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W08-C — Pressing triggers and escape routes: React to a change of possession

**Football situation:** Press is beaten; players abort the chase and recover into useful positions.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can players start and stop a press for observable reasons?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W09-A — Midseason transfer under variation: Draw pressure and switch

**Football situation:** Repeat a switching problem against a less ball-oriented defending unit.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are useful choices robust to changes in opponents and teammate capability?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W09-B — Midseason transfer under variation: Receive, support and combine

**Football situation:** Repeat support play with different teammate strengths using unchanged physics limits.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are useful choices robust to changes in opponents and teammate capability?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W09-C — Midseason transfer under variation: Pressure, cover and balance

**Football situation:** Observe cover and balance with no designated first defender shown.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are useful choices robust to changes in opponents and teammate capability?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W10-A — Rest defense supports attack: Wide overload and box movement

**Football situation:** Two attackers threaten the box while the supporting midfielder protects the central counter.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team attack without leaving every player ahead of the ball?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S2-W10-B — Rest defense supports attack: React to a change of possession

**Football situation:** A wide loss creates a central counter opportunity; nearest and deeper players choose different jobs.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team attack without leaving every player ahead of the ball?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W10-C — Rest defense supports attack: Pressure, cover and balance

**Football situation:** Central defender considers stepping while the holding midfielder may or may not cover.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the team attack without leaving every player ahead of the ball?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W11-A — Timing depth and the second striker: Receive, support and combine

**Football situation:** 9 checks short and a second attacker times a run beyond the line under host offside rules.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are runs timed to the pass and supported by a clear width handover?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W11-B — Timing depth and the second striker: Wide overload and box movement

**Football situation:** Far winger narrows only when width is maintained and the ball can reach the scoring area.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are runs timed to the pass and supported by a clear width handover?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S2-W11-C — Timing depth and the second striker: Create and finish

**Football situation:** Near and far runners respond to the carrier rather than entering the same finishing lane.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Are runs timed to the pass and supported by a clear width handover?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S2-W12-A — Transitions with unequal recovery: React to a change of possession

**Football situation:** A real turnover finds one player behind play; others decide pressure versus recovery.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the unit’s choices change as the recovering player arrives?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W12-B — Transitions with unequal recovery: Pressure, cover and balance

**Football situation:** Defender protects central access until the recovering teammate can provide cover.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the unit’s choices change as the recovering player arrives?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W12-C — Transitions with unequal recovery: Goalkeeper and back-line unit

**Football situation:** GK reads a through-ball while both attacker and defender approach under normal movement limits.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the unit’s choices change as the recovering player arrives?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W13-A — Solve different defensive shapes: Play out under pressure

**Football situation:** Opponent presents a narrow central screen with wide outlets initially available.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack exploit what the opponent leaves open?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W13-B — Solve different defensive shapes: Draw pressure and switch

**Football situation:** Opponent protects width more strongly, leaving a possible central progression.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack exploit what the opponent leaves open?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W13-C — Solve different defensive shapes: Receive, support and combine

**Football situation:** Opposition tracks a receiver tightly; support player creates a new route without a forced pattern.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the attack exploit what the opponent leaves open?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W14-A — Manage match risk: React to a change of possession

**Football situation:** Late-game lead: a regain offers a risky counter and a reliable retention option.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does score context change risk sensibly without predetermined outcomes?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W14-B — Manage match risk: Play out under pressure

**Football situation:** Level game: back-line player chooses progression without needless own-goal exposure.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does score context change risk sensibly without predetermined outcomes?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W14-C — Manage match risk: Create and finish

**Football situation:** Late-game deficit: attacker accepts reasonable risk while still recognizing a better placed teammate.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does score context change risk sensibly without predetermined outcomes?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

### S2-W15-A — Restarts into open play: Play out under pressure

**Football situation:** Begin from a legal host goal-kick setup, then release all players into normal play.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team organize for the second action after a restart?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W15-B — Restarts into open play: Goalkeeper and back-line unit

**Football situation:** Begin after an actual keeper claim; compare the current approved distribution options.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team organize for the second action after a restart?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W15-C — Restarts into open play: Pressure, cover and balance

**Football situation:** Begin from a host-supported sideline restart and defend the next action.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Does the team organize for the second action after a restart?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W16-A — Execute with less help: Receive, support and combine

**Football situation:** No cue overlay; receiver and third player organize from the same visible information.

**Game choice:** C1 (Give and go or turn, 5 players); C2 (Third player choice, 7 players); C3 (Find the pocket, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you help the receiver before the ball arrives?

**Learning evidence:** Offer a reachable passing angle or exploit a third-player opening without running offside.

**9v9 transfer context:** Receiver checks away then offers an angle; Third player moves as the passer commits; 9 can set or turn; Defender follows ball and runner cues. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the player perform without training-only hints?

**Role routes:** 6 → combine; 8 → combine; 9 → combine; GK → keeper (complementary); CB → build (complementary); LB → build (complementary); RB → build (complementary); LW → combine; RW → combine. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| RW | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |

### S2-W16-B — Execute with less help: Draw pressure and switch

**Football situation:** No target highlighting; carrier finds the more useful side through normal perception.

**Game choice:** S1 (Two goals to choose, 6 players); S2 (Connect the opposite side, 9 players); S3 (Switch then exploit, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Has the defender moved enough to open the other side?

**Learning evidence:** Switch when far-side access improves; continue forward when the same-side route remains better.

**9v9 transfer context:** Carrier attacks available space; Near support connects; Far winger stays available until width is handed over; Cover player protects the middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the player perform without training-only hints?

**Role routes:** 6 → switch; 8 → switch; 9 → combine (complementary); GK → keeper (complementary); CB → defend (complementary); LB → switch; RB → switch; LW → switch; RW → switch. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 8 | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| 9 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RB | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| LW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |
| RW | Has the defender moved enough to open the other side? | Switch when far-side access improves; continue forward when the same-side route remains better |

### S2-W16-C — Execute with less help: React to a change of possession

**Football situation:** No pressure/cover labels; unit must coordinate after real possession changes.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Can the player perform without training-only hints?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W17-A — Competition rehearsal: Pressure, cover and balance

**Football situation:** Short scenario against a dangerous central attacker with an available wide runner.

**Game choice:** D1 (Delay and cover, 4 players); D2 (Protect two threats, 6 players); D3 (Press as a unit, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can you win it, or should you slow the attack?

**Learning evidence:** Delay or regain while a teammate covers; a foul or reckless chase is not success.

**9v9 transfer context:** First defender controls approach; Second covers the dangerous inside route; Far player protects a second threat; Front player curves pressure without exposing middle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the team relationships remain stable under competition context?

**Role routes:** 6 → defend; 8 → defend; 9 → defend; GK → keeper (complementary); CB → defend; LB → defend; RB → defend; LW → defend; RW → defend. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 8 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W17-B — Competition rehearsal: Wide overload and box movement

**Football situation:** Attack begins against a balanced defense; no manufactured overload or success boost.

**Game choice:** W1 (Wide two against one, 4 players); W2 (Overlap or stay, 7 players); W3 (Far-side arrival, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Who holds width if somebody runs inside?

**Learning evidence:** Separate runs, preserve a reset, and choose cutback or carry from observed space.

**9v9 transfer context:** Winger can carry inside or outside; Back overlaps only with cover; 9 attacks one finishing lane; Far winger narrows only after width handover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the team relationships remain stable under competition context?

**Role routes:** 6 → transition (complementary); 8 → wide; 9 → wide; GK → keeper (complementary); CB → defend (complementary); LB → wide; RB → wide; LW → wide; RW → wide. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| 9 | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RB | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| LW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |
| RW | Who holds width if somebody runs inside? | Separate runs, preserve a reset, and choose cutback or carry from observed space |

### S2-W17-C — Competition rehearsal: Goalkeeper and back-line unit

**Football situation:** Keeper unit handles a sequence of normal play, save or out, and legal restart.

**Game choice:** K1 (Keeper plus outlets, 5 players); K2 (Protect goal or space, 6 players); K3 (Keeper in the team, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Protect the goal, defend space, or distribute?

**Learning evidence:** Choose set, sweep or distribution from observed arrival and pressure.

**9v9 transfer context:** GK reads ball travel and runner arrival; CB protects goal if GK advances; Outside backs provide split outlets; Opponent presses a visible touch, not hidden inputs. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Do the team relationships remain stable under competition context?

**Role routes:** 6 → keeper; 8 → combine (complementary); 9 → defend (complementary); GK → keeper; CB → keeper; LB → keeper; RB → keeper; LW → defend (complementary); RW → defend (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| 8 | Can you help the receiver before the ball arrives? | Offer a reachable passing angle or exploit a third-player opening without running offside |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| RB | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| LW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RW | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |

### S2-W18-A — Season-two transfer and next steps: Play out under pressure

**Football situation:** Reassess build-up in free play against a different allowed press.

**Game choice:** B1 (Find the exit, 6 players); B2 (Break the first press, 8 players); B3 (Two-way build, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Can we play through, around, or safely reset?

**Learning evidence:** Recognize a reachable outlet without exposing an immediate central turnover.

**9v9 transfer context:** GK offers a return angle; CB draws a presser before releasing; 6 moves out of the cover shadow; Defenders press with cover. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which skills show retained 9v9 evidence, and which should carry into the next development block?

**Role routes:** 6 → build; 8 → build; 9 → defend (complementary); GK → build; CB → build; LB → build; RB → build; LW → transition (complementary); RW → transition (complementary). Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 8 | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| 9 | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| RB | Can we play through, around, or safely reset? | Recognize a reachable outlet without exposing an immediate central turnover |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W18-B — Season-two transfer and next steps: React to a change of possession

**Football situation:** Reassess attack-to-defense and defense-to-attack without extra training rewards.

**Game choice:** T1 (Win it and find space, 6 players); T2 (Pressure with a spare, 7 players); T3 (Protect the counter, 12 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is there a safe counterpress, or do we recover?

**Learning evidence:** Choose press or recovery using support and threat, not an unconditional countdown.

**9v9 transfer context:** Nearest effective player pressures if supported; 6 protects the central counter; Runner offers an outlet on regain; GK adjusts to ball pressure and depth. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which skills show retained 9v9 evidence, and which should carry into the next development block?

**Role routes:** 6 → transition; 8 → transition; 9 → transition; GK → keeper (complementary); CB → transition; LB → transition; RB → transition; LW → transition; RW → transition. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 9 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RB | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| LW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| RW | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |

### S2-W18-C — Season-two transfer and next steps: Create and finish

**Football situation:** Assess finishing choices and enabling off-ball runs separately from goals scored.

**Game choice:** F1 (Pass or finish, 4 players); F2 (Three finishers, two defenders, 6 players); F3 (Finish under equal pressure, 10 players). Select only the player's earned level up to this session's cap of 3; lower levels remain valid. Full geometry, goals and turnover rules are in PRACTICE_CARDS.md.

**Coach question:** Is the shot better than the next pass?

**Learning evidence:** Choose a feasible finish or better teammate; distinguish decision from shot execution.

**9v9 transfer context:** Carrier compares shot and pass; 9 separates from marker; Second attacker supports rebound without blocking shot; GK sets from ball angle. These describe the full-team relationship, not simultaneous duties for nonexistent small-game actors. Actual per-actor duties and starts are in scenario-layouts.json.

**Match transfer:** Which skills show retained 9v9 evidence, and which should carry into the next development block?

**Role routes:** 6 → transition (complementary); 8 → finish; 9 → finish; GK → finish; CB → defend (complementary); LB → defend (complementary); RB → defend (complementary); LW → finish; RW → finish. Complementary sessions must be labeled and adapted to this week's team problem by the host author.

**Delivery:** three short bouts: explore the stated setup; repeat with one mirrored or otherwise legally varied start; remove optional hints and observe independent choices. Choose reduced bout duration before creating the run.

| Career role | Resolved practice question | Evidence objective |
|---|---|---|
| 6 | Is there a safe counterpress, or do we recover? | Choose press or recovery using support and threat, not an unconditional countdown |
| 8 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| 9 | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| GK | Protect the goal, defend space, or distribute? | Choose set, sweep or distribution from observed arrival and pressure |
| CB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| RB | Can you win it, or should you slow the attack? | Delay or regain while a teammate covers; a foul or reckless chase is not success |
| LW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |
| RW | Is the shot better than the next pass? | Choose a feasible finish or better teammate; distinguish decision from shot execution |

